(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/counter.tsx.8a2dafec.js")
    );
  })().catch(console.error);

})();
