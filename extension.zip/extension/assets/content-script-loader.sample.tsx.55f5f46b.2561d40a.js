(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/sample.tsx.55f5f46b.js")
    );
  })().catch(console.error);

})();
